// backend/src/scripts/create_test_tournaments.js

const db = require('../config/database');

// Grilles Sudoku pour les tournois
const grids = {
  facile: {
    grid: [
      [5,3,0,0,7,0,0,0,0],
      [6,0,0,1,9,5,0,0,0],
      [0,9,8,0,0,0,0,6,0],
      [8,0,0,0,6,0,0,0,3],
      [4,0,0,8,0,3,0,0,1],
      [7,0,0,0,2,0,0,0,6],
      [0,6,0,0,0,0,2,8,0],
      [0,0,0,4,1,9,0,0,5],
      [0,0,0,0,8,0,0,7,9]
    ],
    solution: [
      [5,3,4,6,7,8,9,1,2],
      [6,7,2,1,9,5,3,4,8],
      [1,9,8,3,4,2,5,6,7],
      [8,5,9,7,6,1,4,2,3],
      [4,2,6,8,5,3,7,9,1],
      [7,1,3,9,2,4,8,5,6],
      [9,6,1,5,3,7,2,8,4],
      [2,8,7,4,1,9,6,3,5],
      [3,4,5,2,8,6,1,7,9]
    ]
  },
  moyen: {
    grid: [
      [0,0,0,2,6,0,7,0,1],
      [6,8,0,0,7,0,0,9,0],
      [1,9,0,0,0,4,5,0,0],
      [8,2,0,1,0,0,0,4,0],
      [0,0,4,6,0,2,9,0,0],
      [0,5,0,0,0,3,0,2,8],
      [0,0,9,3,0,0,0,7,4],
      [0,4,0,0,5,0,0,3,6],
      [7,0,3,0,1,8,0,0,0]
    ],
    solution: [
      [4,3,5,2,6,9,7,8,1],
      [6,8,2,5,7,1,4,9,3],
      [1,9,7,8,3,4,5,6,2],
      [8,2,6,1,9,5,3,4,7],
      [3,7,4,6,8,2,9,1,5],
      [9,5,1,7,4,3,6,2,8],
      [5,1,9,3,2,6,8,7,4],
      [2,4,8,9,5,7,1,3,6],
      [7,6,3,4,1,8,2,5,9]
    ]
  },
  difficile: {
    grid: [
      [0,0,0,6,0,0,4,0,0],
      [7,0,0,0,0,3,6,0,0],
      [0,0,0,0,9,1,0,8,0],
      [0,0,0,0,0,0,0,0,0],
      [0,5,0,1,8,0,0,0,3],
      [0,0,0,3,0,6,0,4,5],
      [0,4,0,2,0,0,0,6,0],
      [9,0,3,0,0,0,0,0,0],
      [0,2,0,0,0,0,1,0,0]
    ],
    solution: [
      [5,8,1,6,7,2,4,3,9],
      [7,9,2,8,4,3,6,5,1],
      [3,6,4,5,9,1,7,8,2],
      [4,3,8,9,5,7,2,1,6],
      [2,5,6,1,8,4,9,7,3],
      [1,7,9,3,2,6,8,4,5],
      [8,4,5,2,1,9,3,6,7],
      [9,1,3,7,6,8,5,2,4],
      [6,2,7,4,3,5,1,9,8]
    ]
  },
  extreme: {
    grid: [
      [0,0,0,0,0,0,0,0,0],
      [0,0,0,0,0,3,0,8,5],
      [0,0,1,0,2,0,0,0,0],
      [0,0,0,5,0,7,0,0,0],
      [0,0,4,0,0,0,1,0,0],
      [0,9,0,0,0,0,0,0,0],
      [5,0,0,0,0,0,0,7,3],
      [0,0,2,0,1,0,0,0,0],
      [0,0,0,0,4,0,0,0,9]
    ],
    solution: [
      [9,8,7,6,5,4,3,2,1],
      [2,4,6,1,7,3,9,8,5],
      [3,5,1,9,2,8,7,4,6],
      [1,2,8,5,3,7,6,9,4],
      [6,3,4,8,9,2,1,5,7],
      [7,9,5,4,6,1,8,3,2],
      [5,1,9,2,8,6,4,7,3],
      [4,7,2,3,1,9,5,6,8],
      [8,6,3,7,4,5,2,1,9]
    ]
  }
};

function createTournaments() {
  console.log('🏆 Création des tournois de test...\n');
  
  // Get current date and add days
  const now = new Date();
  const endDate = new Date(now);
  endDate.setDate(endDate.getDate() + 7); // 7 jours

  const difficulties = ['facile', 'moyen', 'difficile', 'extreme'];
  const names = [
    'Tournoi Hebdomadaire Facile',
    'Tournoi Hebdomadaire Moyen',
    'Tournoi Hebdomadaire Difficile',
    'Tournoi Hebdomadaire Extrême'
  ];

  difficulties.forEach((difficulty, index) => {
    const gridData = grids[difficulty];
    
    const sql = `
      INSERT INTO tournaments (name, grid, solution, difficulty, start_date, end_date, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `;
    
    db.run(
      sql,
      [
        names[index],
        JSON.stringify(gridData.grid),
        JSON.stringify(gridData.solution),
        difficulty,
        now.toISOString(),
        endDate.toISOString(),
        'active'
      ],
      function(err) {
        if (err) {
          console.error(`❌ Erreur création tournoi ${difficulty}:`, err.message);
        } else {
          console.log(`✅ Tournoi créé: ${names[index]} (ID: ${this.lastID})`);
        }
      }
    );
  });

  setTimeout(() => {
    console.log('\n🎉 Tous les tournois ont été créés !');
    console.log('📊 Vérifiez dans l\'app maintenant.\n');
    process.exit(0);
  }, 1000);
}

// Exécuter
createTournaments();