const Duel = require('../models/Duel');
const User = require('../models/User');
const { generateSudoku } = require('./sudokuGenerator');

let io;
const waitingPlayers = new Map(); // difficulty -> [players]
const activeDuels = new Map();    // duelId -> { player1Socket, player2Socket, player1Id, player2Id }

// ✅ NOUVEAU : Gestion de la présence des utilisateurs
const onlineUsers = new Map(); // userId -> socketId

// ✅ NOUVEAU : Pour les duels par invitation, les deux joueurs s'enregistrent
// via 'register_duel'. Dès que les deux sont connectés → activeDuels est peuplé.
const pendingDuelRegistrations = new Map();

// ==========================================
// BOT SIMULATION
// ==========================================
const BOT_USER = {
  userId: 999,
  username: 'amitest',
  socketId: 'bot-socket-id',
};

function simulateBotPlay(duelId, solution, playerSocketId) {
  let progress = 0;
  let mistakes = 0;
  
  console.log(`🤖 Bot started playing in duel ${duelId}`);
  
  const botInterval = setInterval(() => {
    if (!activeDuels.has(duelId)) {
      clearInterval(botInterval);
      console.log(`🤖 Bot stopped - duel ${duelId} no longer active`);
      return;
    }
    
    const increment = Math.floor(Math.random() * 11) + 5;
    progress = Math.min(100, progress + increment);
    
    if (Math.random() < 0.15 && mistakes < 2) {
      mistakes++;
      console.log(`🤖 Bot made a mistake! (${mistakes}/3)`);
    }
    
    Duel.updateProgress(duelId, BOT_USER.userId, progress, mistakes)
      .catch(err => console.error('Bot progress update error:', err));
    
    io.to(playerSocketId).emit('opponent_progress', { 
      progress, 
      mistakes 
    });
    
    console.log(`🤖 Bot progress: ${progress}% (${mistakes} mistakes)`);
    
    if (mistakes >= 3) {
      clearInterval(botInterval);
      io.to(playerSocketId).emit('opponent_eliminated');
      Duel.complete(duelId, duelId.player1Id)
        .catch(err => console.error('Bot elimination completion error:', err));
      activeDuels.delete(duelId);
      console.log(`💀 Bot eliminated by 3 mistakes in duel ${duelId}`);
      return;
    }
    
    if (progress >= 95) {
      clearInterval(botInterval);
      console.log(`🤖 Bot approaching completion at ${progress}%...`);
      setTimeout(() => {
        if (activeDuels.has(duelId)) {
          console.log(`🤖 Bot finished! Player should win by being faster.`);
        }
      }, 5000);
    }
    
  }, 4000);
}

// ==========================================
// ✅ HELPER: Broadcaster le statut online des amis
// ==========================================
function broadcastFriendsStatus(userId) {
  // Envoyer à tous les utilisateurs en ligne le statut de leurs amis
  io.emit('friends_status_update');
}

// ==========================================
// SOCKET SERVICE
// ==========================================

exports.initializeSocket = (socketIo) => {
  io = socketIo;
  
  io.on('connection', (socket) => {
    console.log(`✅ Socket connected: ${socket.id}`);
    
    // ==========================================
    // ✅ PRÉSENCE UTILISATEUR
    // ==========================================
    
    socket.on('user_online', async (userId) => {
      try {
        console.log(`👤 User ${userId} is now ONLINE`);
        
        // Stocker le socket de l'utilisateur
        onlineUsers.set(userId, socket.id);
        
        // Broadcaster aux amis que cet utilisateur est en ligne
        broadcastFriendsStatus(userId);
        
      } catch (error) {
        console.error('Error handling user_online:', error);
      }
    });
    
    socket.on('user_offline', async (userId) => {
      try {
        console.log(`👤 User ${userId} is now OFFLINE`);
        
        // Retirer de la liste des utilisateurs en ligne
        onlineUsers.delete(userId);
        
        // Broadcaster aux amis que cet utilisateur est hors ligne
        broadcastFriendsStatus(userId);
        
      } catch (error) {
        console.error('Error handling user_offline:', error);
      }
    });
    
    // ✅ Vérifier si un utilisateur est en ligne
    socket.on('check_user_status', ({ userId }, callback) => {
      const isOnline = onlineUsers.has(userId);
      callback({ isOnline });
    });
    
    // ✅ Vérifier le statut de plusieurs utilisateurs (liste d'amis)
    socket.on('check_friends_status', ({ friendIds }, callback) => {
      const statuses = {};
      friendIds.forEach(friendId => {
        statuses[friendId] = onlineUsers.has(friendId);
      });
      callback(statuses);
    });
    
    // ==========================================
    // MATCHMAKING
    // ==========================================
    
    socket.on('search_duel', async ({ difficulty, userId }) => {
      try {
        console.log(`🔍 User ${userId} searching for ${difficulty} duel`);
        
        if (!waitingPlayers.has(difficulty)) {
          waitingPlayers.set(difficulty, []);
        }
        
        const waiting = waitingPlayers.get(difficulty);
        
        if (waiting.length > 0) {
          const opponent = waiting.shift();
          
          console.log(`🎮 Real player match found! ${userId} vs ${opponent.userId}`);
          
          const { grid, solution } = generateSudoku(difficulty);
          const result = await Duel.create(opponent.userId, userId, grid, solution, difficulty);
          const duel = await Duel.findById(result.id);
          
          const player1 = await User.findById(opponent.userId);
          const player2 = await User.findById(userId);
          
          const duelData = {
            id: duel.id,
            player1_id: duel.player1_id,
            player2_id: duel.player2_id,
            player1_name: player1.username,
            player2_name: player2.username,
            grid: duel.grid,
            solution: duel.solution,
            difficulty: duel.difficulty,
            status: duel.status,
            player1_progress: 0,
            player2_progress: 0,
            player1_mistakes: 0,
            player2_mistakes: 0,
            created_at: duel.created_at,
          };
          
          activeDuels.set(duel.id, {
            player1Socket: opponent.socketId,
            player2Socket: socket.id,
            player1Id: opponent.userId,
            player2Id: userId,
          });
          
          io.to(opponent.socketId).emit('duel_found', duelData);
          io.to(socket.id).emit('duel_found', duelData);
          
          console.log(`✅ Real player duel ${duel.id} created between ${opponent.userId} and ${userId}`);
          
        } else {
          // ✅ Bug corrigé : le bot était créé IMMÉDIATEMENT si personne n'attendait.
          // Si deux joueurs lancent la recherche presque en même temps, le premier
          // obtenait un bot avant que le second arrive dans la file.
          // On attend maintenant 8 secondes pour laisser un vrai joueur se connecter.
          // Si un vrai joueur arrive pendant ce délai → le timeout est ignoré.

          console.log(`⏳ No players waiting for ${difficulty}, queuing ${userId} for 8s before bot fallback`);

          // Mettre le joueur dans la file d'attente
          waiting.push({ userId, socketId: socket.id });

          const botTimeout = setTimeout(async () => {
            // Vérifier si ce joueur est toujours dans la file (pas encore matché)
            const currentWaiting = waitingPlayers.get(difficulty) || [];
            const stillWaiting = currentWaiting.findIndex(p => p.userId === userId && p.socketId === socket.id);
            if (stillWaiting === -1) return; // déjà matché avec un vrai joueur

            // Retirer de la file et créer un bot
            currentWaiting.splice(stillWaiting, 1);

            console.log(`🤖 No real player found after 8s, creating BOT match for user ${userId}`);

            try {
              const { grid, solution } = generateSudoku(difficulty);
              const player = await User.findById(userId);

              if (!player) {
                console.error(`❌ User ${userId} not found`);
                socket.emit('error', { message: 'User not found' });
                return;
              }

              const result = await Duel.create(userId, BOT_USER.userId, grid, solution, difficulty);
              const duel = await Duel.findById(result.id);

              const duelData = {
                id: duel.id,
                player1_id: duel.player1_id,
                player2_id: duel.player2_id,
                player1_name: player.username,
                player2_name: BOT_USER.username,
                grid: duel.grid,
                solution: duel.solution,
                difficulty: duel.difficulty,
                status: 'active',
                player1_progress: 0,
                player2_progress: 0,
                player1_mistakes: 0,
                player2_mistakes: 0,
                created_at: duel.created_at,
              };

              activeDuels.set(duel.id, {
                player1Socket: socket.id,
                player2Socket: BOT_USER.socketId,
                player1Id: userId,
                player2Id: BOT_USER.userId,
              });

              io.to(socket.id).emit('duel_found', duelData);
              simulateBotPlay(duel.id, duel.solution, socket.id);
              console.log(`✅ Bot duel ${duel.id} created: ${player.username} vs ${BOT_USER.username}`);
            } catch (err) {
              console.error('Bot duel creation error:', err);
            }
          }, 8000);
        }
        
      } catch (error) {
        console.error('Search duel error:', error);
        socket.emit('error', { message: 'Failed to search for opponent' });
      }
    });
    
    socket.on('cancel_search', ({ difficulty, userId }) => {
      if (waitingPlayers.has(difficulty)) {
        const waiting = waitingPlayers.get(difficulty);
        const index = waiting.findIndex(p => p.userId === userId);
        
        if (index !== -1) {
          waiting.splice(index, 1);
          console.log(`❌ User ${userId} cancelled search`);
        }
      }
    });
    
    // ==========================================
    // GAMEPLAY
    // ==========================================
    
    socket.on('update_progress', async ({ duel_id, progress, mistakes }) => {
      try {
        const duelInfo = activeDuels.get(duel_id);
        
        if (!duelInfo) return;
        
        const isPlayer1 = socket.id === duelInfo.player1Socket;
        const opponentSocket = isPlayer1 ? duelInfo.player2Socket : duelInfo.player1Socket;
        
        const duel = await Duel.findById(duel_id);
        const playerId = isPlayer1 ? duel.player1_id : duel.player2_id;
        
        await Duel.updateProgress(duel_id, playerId, progress, mistakes || 0);
        
        if (opponentSocket !== BOT_USER.socketId) {
          io.to(opponentSocket).emit('opponent_progress', { 
            progress, 
            mistakes: mistakes || 0 
          });
        }
        
        console.log(`📊 Progress updated for duel ${duel_id}: ${progress}% (${mistakes} mistakes)`);
        
      } catch (error) {
        console.error('Update progress error:', error);
      }
    });
    
    socket.on('duel_completed', async ({ duel_id }) => {
      try {
        const duelInfo = activeDuels.get(duel_id);
        
        if (!duelInfo) return;
        
        const isPlayer1 = socket.id === duelInfo.player1Socket;
        const opponentSocket = isPlayer1 ? duelInfo.player2Socket : duelInfo.player1Socket;
        const myId = isPlayer1 ? duelInfo.player1Id : duelInfo.player2Id;
        
        // ✅ Bug corrigé : avant, on déclarait TOUJOURS l'émetteur gagnant.
        // Comme les deux joueurs finissent par terminer leur grille, le 2e
        // à émettre 'duel_completed' réécrasait le résultat du 1er → les
        // DEUX joueurs se voyaient "Victoire". On vérifie maintenant l'état
        // réel en base avant de trancher.
        const existing = await Duel.findById(duel_id);
        let winnerId;
        
        if (existing && existing.status === 'finished' && existing.winner_id) {
          // L'adversaire a déjà fini avant nous : le résultat est figé.
          winnerId = existing.winner_id;
        } else {
          const result = await Duel.complete(duel_id, myId);
          if (result.changes > 0) {
            winnerId = myId;
          } else {
            // Course perdue de quelques millisecondes contre l'adversaire.
            const refreshed = await Duel.findById(duel_id);
            winnerId = refreshed.winner_id;
          }
        }
        
        const winnerRole = winnerId === duelInfo.player1Id ? 'player1' : 'player2';
        
        // Notifier les DEUX joueurs avec le MÊME résultat (réel).
        io.to(socket.id).emit('duel_finished', { winner_id: winnerRole });
        
        if (opponentSocket !== BOT_USER.socketId) {
          io.to(opponentSocket).emit('duel_finished', { 
            winner_id: winnerRole 
          });
        }
        
        activeDuels.delete(duel_id);
        
        console.log(`🏆 Duel ${duel_id} completed - Winner: ${winnerId}`);
        
      } catch (error) {
        console.error('Duel completed error:', error);
      }
    });
    
    socket.on('player_eliminated', async ({ duel_id }) => {
      try {
        const duelInfo = activeDuels.get(duel_id);
        
        if (!duelInfo) return;
        
        const isPlayer1 = socket.id === duelInfo.player1Socket;
        const opponentSocket = isPlayer1 ? duelInfo.player2Socket : duelInfo.player1Socket;
        const winnerId = isPlayer1 ? duelInfo.player2Id : duelInfo.player1Id;
        
        await Duel.complete(duel_id, winnerId);
        
        if (opponentSocket !== BOT_USER.socketId) {
          io.to(opponentSocket).emit('opponent_eliminated');
        }
        
        activeDuels.delete(duel_id);
        
        console.log(`⚠️ Player eliminated in duel ${duel_id} - Winner: ${winnerId}`);
        
      } catch (error) {
        console.error('Player elimination error:', error);
      }
    });
    
    socket.on('abandon_duel', async ({ duel_id }) => {
      try {
        const duelInfo = activeDuels.get(duel_id);
        
        if (!duelInfo) return;
        
        const isPlayer1 = socket.id === duelInfo.player1Socket;
        const opponentSocket = isPlayer1 ? duelInfo.player2Socket : duelInfo.player1Socket;
        const winnerId = isPlayer1 ? duelInfo.player2Id : duelInfo.player1Id;
        
        await Duel.complete(duel_id, winnerId);
        
        if (opponentSocket !== BOT_USER.socketId) {
          io.to(opponentSocket).emit('opponent_disconnected');
        }
        
        activeDuels.delete(duel_id);
        
        console.log(`🏃 Player abandoned duel ${duel_id} - Winner by default: ${winnerId}`);
        
      } catch (error) {
        console.error('Abandon duel error:', error);
      }
    });
    
    // ==========================================
    // IN-GAME MESSAGES
    // ==========================================
    
    socket.on('duel_message', ({ duel_id, sender_id, content }) => {
      try {
        const duelInfo = activeDuels.get(duel_id);
        
        if (!duelInfo) return;
        
        const isPlayer1 = socket.id === duelInfo.player1Socket;
        const opponentSocket = isPlayer1 ? duelInfo.player2Socket : duelInfo.player1Socket;
        
        if (opponentSocket !== BOT_USER.socketId) {
          io.to(opponentSocket).emit('duel_message', { 
            sender_id,
            content 
          });
        } else {
          const botMessages = [
            '👍 Bien joué !',
            '😎 Continue comme ça',
            '🔥 Tu es en feu !',
            '💪 Fort !',
            '⚡ Rapide !',
          ];
          
          setTimeout(() => {
            const randomMsg = botMessages[Math.floor(Math.random() * botMessages.length)];
            io.to(socket.id).emit('duel_message', {
              sender_id: BOT_USER.userId,
              content: randomMsg,
            });
            console.log(`🤖 Bot replied: "${randomMsg}"`);
          }, 1500);
        }
        
        console.log(`💬 Message sent in duel ${duel_id}: "${content}"`);
        
      } catch (error) {
        console.error('Duel message error:', error);
      }
    });
    
    // ==========================================
    // REGISTER DUEL (invitations par ami)
    // ==========================================
    //
    // ✅ Bug corrigé : pour les duels par invitation, activeDuels n'était jamais
    // peuplé → tous les 'update_progress' étaient silencieusement ignorés.
    //
    // Chaque joueur émet 'register_duel' après avoir reçu 'duel_accepted'.
    // Dès que les deux sont enregistrés, on crée l'entrée dans activeDuels.

    socket.on('register_duel', ({ duel_id, player1_id, player2_id }) => {
      try {
        // Chercher à quel userId appartient ce socket via onlineUsers
        let currentUserId = null;
        for (const [uid, sid] of onlineUsers.entries()) {
          if (sid === socket.id) { currentUserId = uid; break; }
        }

        // Comparer en Number (les IDs peuvent arriver comme String ou Number)
        const p1 = Number(player1_id);
        const p2 = Number(player2_id);
        const me = Number(currentUserId);

        if (!pendingDuelRegistrations.has(duel_id)) {
          pendingDuelRegistrations.set(duel_id, {
            player1_id: p1, player2_id: p2,
            player1Socket: null, player2Socket: null,
          });
        }

        const reg = pendingDuelRegistrations.get(duel_id);
        if (me === p1)      reg.player1Socket = socket.id;
        else if (me === p2) reg.player2Socket = socket.id;

        console.log(`📋 register_duel ${duel_id}: p1=${reg.player1Socket ? '✅' : '⏳'} p2=${reg.player2Socket ? '✅' : '⏳'}`);

        if (reg.player1Socket && reg.player2Socket) {
          activeDuels.set(duel_id, {
            player1Socket: reg.player1Socket,
            player2Socket: reg.player2Socket,
            player1Id: reg.player1_id,
            player2Id: reg.player2_id,
          });
          pendingDuelRegistrations.delete(duel_id);
          console.log(`✅ Duel ${duel_id} activé dans activeDuels (via invitation)`);
        }
      } catch (error) {
        console.error('register_duel error:', error);
      }
    });

    // ==========================================
    // DISCONNECT HANDLING
    // ==========================================
    
    socket.on('disconnect', () => {
      console.log(`❌ Socket disconnected: ${socket.id}`);
      
      // ✅ Retirer de la liste des utilisateurs en ligne
      for (const [userId, socketId] of onlineUsers.entries()) {
        if (socketId === socket.id) {
          onlineUsers.delete(userId);
          console.log(`👤 User ${userId} went OFFLINE (disconnect)`);
          broadcastFriendsStatus(userId);
          break;
        }
      }
      
      for (const [difficulty, waiting] of waitingPlayers.entries()) {
        const index = waiting.findIndex(p => p.socketId === socket.id);
        if (index !== -1) {
          waiting.splice(index, 1);
          console.log(`🗑️ Removed from ${difficulty} waiting list`);
        }
      }
      
      for (const [duelId, duelInfo] of activeDuels.entries()) {
        if (duelInfo.player1Socket === socket.id || duelInfo.player2Socket === socket.id) {
          const opponentSocket = duelInfo.player1Socket === socket.id 
            ? duelInfo.player2Socket 
            : duelInfo.player1Socket;
          
          const winnerId = duelInfo.player1Socket === socket.id
            ? duelInfo.player2Id
            : duelInfo.player1Id;
          
          Duel.complete(duelId, winnerId).catch(err => {
            console.error('Error completing duel on disconnect:', err);
          });
          
          if (opponentSocket !== BOT_USER.socketId) {
            io.to(opponentSocket).emit('opponent_disconnected');
          }
          
          activeDuels.delete(duelId);
          
          console.log(`🔌 Duel ${duelId} ended due to disconnect - Winner: ${winnerId}`);
        }
      }
    });
  });
};

// ✅ NOUVEAU : Fonction pour vérifier si un utilisateur est en ligne
exports.isUserOnline = (userId) => {
  return onlineUsers.has(userId);
};

// ✅ NOUVEAU : Fonction pour récupérer tous les utilisateurs en ligne
exports.getOnlineUsers = () => {
  return Array.from(onlineUsers.keys());
};

exports.getIo = () => io;

// ✅ NOUVEAU : Émettre un événement socket vers UN utilisateur précis (par userId).
// Utilisé par duelController pour cibler les deux joueurs au lieu de io.emit() global.
exports.emitToUser = (userId, event, data) => {
  const numId = Number(userId);
  const socketId = onlineUsers.get(numId) || onlineUsers.get(String(userId));
  if (socketId && io) {
    io.to(socketId).emit(event, data);
    console.log(`📡 emitToUser: ${event} → user ${userId} (socket ${socketId})`);
    return true;
  }
  console.warn(`⚠️  emitToUser: user ${userId} not found in onlineUsers`);
  return false;
};